import React, { useEffect, useState, useRef } from 'react';

export default function App() {
  const [reminders, setReminders] = useState(() => {
    try {
      const raw = localStorage.getItem('nailcut.reminders.v1');
      return raw ? JSON.parse(raw) : [];
    } catch (e) {
      return [];
    }
  });
  const [title, setTitle] = useState('');
  const [datetime, setDatetime] = useState('');
  const [repeat, setRepeat] = useState('none');
  const [notes, setNotes] = useState('');
  const timersRef = useRef({});

  useEffect(() => {
    localStorage.setItem('nailcut.reminders.v1', JSON.stringify(reminders));
    clearAllTimers();
    setupTimers();
  }, [reminders]);

  useEffect(() => {
    if (Notification && Notification.permission === 'default') {
      Notification.requestPermission().catch(() => {});
    }
  }, []);

  function clearAllTimers() {
    Object.values(timersRef.current).forEach((id) => clearTimeout(id));
    timersRef.current = {};
  }

  function scheduleReminder(rem) {
    const ms = new Date(rem.datetime).getTime() - Date.now();
    if (ms <= 0) return;
    const id = setTimeout(() => {
      showNotification(rem);
      if (rem.repeat && rem.repeat !== 'none') {
        const next = computeNext(rem.datetime, rem.repeat);
        updateReminder(rem.id, { datetime: next });
      }
    }, ms);
    timersRef.current[rem.id] = id;
  }

  function setupTimers() {
    reminders.forEach((r) => {
      if (new Date(r.datetime).getTime() > Date.now()) {
        scheduleReminder(r);
      }
    });
  }

  function computeNext(currentISO, repeatType) {
    const dt = new Date(currentISO);
    if (repeatType === 'weekly') dt.setDate(dt.getDate() + 7);
    else if (repeatType === 'monthly') dt.setMonth(dt.getMonth() + 1);
    return dt.toISOString();
  }

  function showNotification(rem) {
    const title = `Nailcut reminder: ${rem.title}`;
    const body = rem.notes || `Scheduled at ${new Date(rem.datetime).toLocaleString()}`;
    if (typeof Notification !== 'undefined' && Notification.permission === 'granted') {
      new Notification(title, { body });
    } else alert(`${title}\n\n${body}`);
  }

  function addReminder(e) {
    e?.preventDefault();
    if (!title || !datetime) return alert('Please add a title and date/time');
    const id = Math.random().toString(36).slice(2, 9);
    const rem = { id, title, datetime: new Date(datetime).toISOString(), repeat, notes };
    setReminders((s) => [...s, rem].sort((a, b) => new Date(a.datetime) - new Date(b.datetime)));
    setTitle(''); setDatetime(''); setRepeat('none'); setNotes('');
  }

  function deleteReminder(id) {
    setReminders((s) => s.filter((r) => r.id !== id));
  }

  function updateReminder(id, patch) {
    setReminders((s) => s.map((r) => (r.id === id ? { ...r, ...patch } : r)));
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-6">
      <div className="max-w-3xl mx-auto bg-white shadow-lg rounded-2xl p-6">
        <header className="flex items-center justify-between mb-4">
          <h1 className="text-2xl font-extrabold">Nailcut Reminder</h1>
        </header>
        <form onSubmit={addReminder} className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-4">
          <input className="p-2 border rounded-lg" placeholder="Title" value={title} onChange={(e) => setTitle(e.target.value)} />
          <input type="datetime-local" className="p-2 border rounded-lg" value={datetime} onChange={(e) => setDatetime(e.target.value)} />
          <select className="p-2 border rounded-lg" value={repeat} onChange={(e) => setRepeat(e.target.value)}>
            <option value="none">No repeat</option>
            <option value="weekly">Weekly</option>
            <option value="monthly">Monthly</option>
          </select>
          <textarea className="col-span-3 p-2 border rounded-lg" placeholder="Notes (optional)" value={notes} onChange={(e) => setNotes(e.target.value)} />
          <button className="col-span-3 px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600">Add Reminder</button>
        </form>
        <ul className="space-y-3">
          {reminders.map((r) => (
            <li key={r.id} className="p-3 border rounded-lg flex justify-between items-center">
              <div>
                <h2 className="font-bold">{r.title}</h2>
                <p className="text-sm text-gray-600">{new Date(r.datetime).toLocaleString()}</p>
                {r.notes && <p className="text-sm italic">{r.notes}</p>}
              </div>
              <button onClick={() => deleteReminder(r.id)} className="text-red-500 hover:underline">Delete</button>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
